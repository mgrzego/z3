#ifndef SCENE_HH
#define SCENE_HH


class Scene {

};


#endif
